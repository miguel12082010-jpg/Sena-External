# Sena External para iPhone (PWA)

## Arquivos
- `index.html`: página do site.
- `style.css`: layout adaptável a celular e computador.
- `app.js`: treino e perfis salvos localmente.
- `manifest.webmanifest`, `sw.js` e ícones: suporte de instalação como PWA.

## Publicar gratuitamente
Para instalar no iPhone, o site precisa estar em uma URL HTTPS. Um caminho gratuito:
1. Entre em GitHub e crie um repositório público `sena-external`.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Abra Settings → Pages e habilite publicação pela branch principal (pasta raiz).
4. Espere o GitHub Pages fornecer a URL HTTPS.
5. Abra essa URL no Safari do iPhone.

## Adicionar à Tela de Início no iPhone
1. Abra o site no Safari (não em uma aba interna de outro aplicativo).
2. Toque no botão Compartilhar.
3. Escolha “Adicionar à Tela de Início”.
4. Se a opção “Abrir como app da web” aparecer, habilite-a; toque em Adicionar.

## Notas
- PWA exige hospedagem HTTPS para service worker e instalação confiável.
- Não existe URL pública publicada automaticamente por este pacote; você precisa publicar os arquivos primeiro.
- Dados de treino e perfis ficam no armazenamento local do navegador.
- Os botões da loja são demonstrações, sem pagamento real.
- Não é afiliado à Garena e não altera o Free Fire.
