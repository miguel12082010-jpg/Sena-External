const $=id=>document.getElementById(id);
const read=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const write=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
let stats=read('seStats',{sessions:0,best:null,seconds:0}), profiles=read('seProfiles',[]);
function renderStats(){$('sessions').textContent=stats.sessions;$('best').textContent=stats.best==null?'—':stats.best+' ms';$('minutes').textContent=Math.round(stats.seconds/60)+' min'}
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2500)}
$('year').textContent=new Date().getFullYear();
$('menuBtn').addEventListener('click',()=>$('nav').classList.toggle('open'));
$('nav').querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>$('nav').classList.remove('open')));
renderStats();
let active=false,count=0,startAt=0,timer=null,times=[];
function arenaText(t){$('target').classList.add('hidden');$('arenaText').classList.remove('hidden');$('arenaText').textContent=t}
function schedule(){arenaText('Aguarde o alvo...');timer=setTimeout(()=>{if(!active)return;let ar=$('arena'),t=$('target');t.style.left=Math.floor(Math.random()*Math.max(1,ar.clientWidth-55))+'px';t.style.top=Math.floor(Math.random()*Math.max(1,ar.clientHeight-55))+'px';$('arenaText').classList.add('hidden');t.classList.remove('hidden');startAt=performance.now();$('status').textContent='Alvo! Toque nele'},650+Math.random()*1600)}
function finish(){active=false;clearTimeout(timer);let avg=Math.round(times.reduce((a,b)=>a+b,0)/times.length);stats.sessions++;stats.seconds+=Math.max(1,Math.round(times.reduce((a,b)=>a+b,0)/1000));if(stats.best==null||avg<stats.best)stats.best=avg;write('seStats',stats);renderStats();$('status').textContent='Treino concluído';arenaText('Concluído! Média: '+avg+' ms. Tente novamente para comparar.');$('start').textContent='Treinar novamente'}
$('start').addEventListener('click',()=>{if(active)return;active=true;count=0;times=[];$('attempt').textContent='0 / 10';$('last').textContent='—';$('avg').textContent='—';$('start').textContent='Treino em andamento';$('status').textContent='Concentre-se';schedule()});
$('target').addEventListener('click',()=>{if(!active||$('target').classList.contains('hidden'))return;let ms=Math.round(performance.now()-startAt);times.push(ms);count++;$('attempt').textContent=count+' / 10';$('last').textContent=ms+' ms';$('avg').textContent=Math.round(times.reduce((a,b)=>a+b,0)/times.length)+' ms';$('target').classList.add('hidden');if(count>=10){finish();return}$('status').textContent='Boa! Próximo alvo';schedule()});
const ranges={general:'out-general',red:'out-red',scope2:'out-scope2',scope4:'out-scope4',awm:'out-awm',look:'out-look'};
Object.entries(ranges).forEach(([id,out])=>$(id).addEventListener('input',()=>$(out).textContent=$(id).value));
function apply(p){$('profileName').value=p.name||'';$('dpi').value=p.dpi||'';Object.entries(ranges).forEach(([id,out])=>{$(id).value=p.values?.[id]??100;$(out).textContent=$(id).value})}
function renderProfiles(){let root=$('profiles');root.replaceChildren();if(!profiles.length){let p=document.createElement('p');p.className='muted';p.textContent='Perfis salvos aparecem aqui.';root.append(p);return}profiles.forEach((p,i)=>{let row=document.createElement('div');row.className='profile-item';let title=document.createElement('span');title.textContent=p.name+(p.dpi?' · DPI '+p.dpi:'');let actions=document.createElement('div');let load=document.createElement('button');load.textContent='Carregar';load.onclick=()=>{apply(p);toast('Perfil carregado')};let del=document.createElement('button');del.textContent='Excluir';del.onclick=()=>{profiles.splice(i,1);write('seProfiles',profiles);renderProfiles()};actions.append(load,del);row.append(title,actions);root.append(row)})}
$('profileForm').addEventListener('submit',e=>{e.preventDefault();let name=$('profileName').value.trim();if(!name)return;let p={name,dpi:$('dpi').value?Number($('dpi').value):null,values:{}};Object.keys(ranges).forEach(id=>p.values[id]=Number($(id).value));let i=profiles.findIndex(x=>x.name.toLowerCase()===name.toLowerCase());if(i>=0)profiles[i]=p;else profiles.unshift(p);profiles=profiles.slice(0,10);write('seProfiles',profiles);$('profileMsg').textContent='Perfil salvo neste navegador.';renderProfiles()});
$('reset').addEventListener('click',()=>{apply({name:'',dpi:null,values:{}});$('profileMsg').textContent='Valores restaurados. Salve para guardar.'});
renderProfiles();
document.querySelectorAll('[data-toast]').forEach(b=>b.addEventListener('click',()=>toast(b.dataset.toast)));
if('serviceWorker' in navigator && location.protocol.startsWith('http')){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}
